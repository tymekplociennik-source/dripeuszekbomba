package pl.dripeuszek.bomba;

public enum Theme {
    //            nazwa        accent      tło         sidebar     karta       karta-hover tekst       tekst2      na-accent
    CIEMNY("Ciemny",       0xFF4DA3FF, 0xFF14161A, 0xFF0F1114, 0xFF1C1F25, 0xFF282C34, 0xFFF2F4F8, 0xFF8A93A3, 0xFF0B1220),
    JASNY("Jasny",         0xFF2F6FED, 0xFFF3F5F8, 0xFFE6E9EF, 0xFFFFFFFF, 0xFFE3E8F1, 0xFF1B1F27, 0xFF6B7385, 0xFFFFFFFF),
    FIOLETOWY("Fioletowy", 0xFFA974FF, 0xFF17121F, 0xFF110D18, 0xFF211A2D, 0xFF2D2440, 0xFFF4F0FA, 0xFF9A8DB3, 0xFF1A0F2B),
    ROZOWY("Różowy",       0xFFFF6FAE, 0xFF1D1217, 0xFF160D11, 0xFF281A22, 0xFF36232E, 0xFFFAF0F4, 0xFFB58C9F, 0xFF2A0E1B),
    ZIELONY("Zielony",     0xFF4ADE80, 0xFF101914, 0xFF0B120E, 0xFF17231C, 0xFF203227, 0xFFEFFAF3, 0xFF86A894, 0xFF052012),
    ZLOTY("Złoty",         0xFFFFC857, 0xFF1A1710, 0xFF13110B, 0xFF241F14, 0xFF332B1C, 0xFFFAF6EC, 0xFFB5A67F, 0xFF2A2005);

    public final String label;
    public final int accent, bg, sidebar, card, cardHover, text, sub, onAccent;

    Theme(String label, int accent, int bg, int sidebar, int card, int cardHover, int text, int sub, int onAccent) {
        this.label = label;
        this.accent = accent;
        this.bg = bg;
        this.sidebar = sidebar;
        this.card = card;
        this.cardHover = cardHover;
        this.text = text;
        this.sub = sub;
        this.onAccent = onAccent;
    }

    public static Theme byName(String name) {
        for (Theme t : values()) {
            if (t.name().equals(name)) return t;
        }
        return CIEMNY;
    }

    public static Theme current() {
        return byName(ModConfig.get().theme);
    }
}
