package pl.dripeuszek.bomba;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.Camera;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

/** Rysuje linię (tracer) od dołu ekranu do gracza oznaczonego ATAK. Liczone ręcznie, bez ingerencji w OpenGL. */
public final class Tracers {
    private Tracers() {}

    public static void render(DrawContext ctx, MinecraftClient mc, float tickDelta) {
        if (!AttackManager.isActive() || mc.world == null || mc.player == null) return;
        PlayerEntity target = mc.world.getPlayerByUuid(AttackManager.targetId());
        if (target == null || target == mc.player) return;

        Theme t = Theme.current();
        Camera cam = mc.gameRenderer.getCamera();
        Vec3d pos = target.getLerpedPos(tickDelta).add(0, target.getHeight() / 2.0, 0);
        Vec3d rel = pos.subtract(cam.getPos());

        double yaw = Math.toRadians(cam.getYaw()), pitch = Math.toRadians(cam.getPitch());
        double sy = Math.sin(yaw), cy = Math.cos(yaw), sp = Math.sin(pitch), cp = Math.cos(pitch);
        double fx = -sy * cp, fy = -sp, fz = cy * cp;      // kierunek patrzenia
        double rx = -cy, rz = -sy;                          // prawo
        double ux = -sy * sp, uy = cp, uz = cy * sp;        // góra

        double depth = rel.x * fx + rel.y * fy + rel.z * fz;
        double sideX = rel.x * rx + rel.z * rz;
        double sideY = rel.x * ux + rel.y * uy + rel.z * uz;

        int sw = mc.getWindow().getScaledWidth(), sh = mc.getWindow().getScaledHeight();
        float ox = sw / 2f, oy = sh - 4f;
        float ex, ey;
        boolean behind = depth <= 0.05;

        if (!behind) {
            double fov = Math.toRadians(mc.options.getFov().getValue());
            double th = Math.tan(fov / 2.0);
            double aspect = (double) sw / sh;
            double ndcX = sideX / (depth * th * aspect);
            double ndcY = sideY / (depth * th);
            ex = (float) ((ndcX * 0.5 + 0.5) * sw);
            ey = (float) ((0.5 - ndcY * 0.5) * sh);
        } else {
            double len = Math.hypot(sideX, sideY);
            if (len < 1e-4) { sideX = 0; sideY = -1; len = 1; }
            ex = sw / 2f + (float) (sideX / len) * sw * 0.45f;
            ey = sh / 2f - (float) (sideY / len) * sh * 0.45f;
        }

        // ogranicz długość, żeby nie rysować absurdalnie długich linii
        float dx = ex - ox, dy = ey - oy;
        float max = 3f * Math.max(sw, sh);
        float len = (float) Math.sqrt(dx * dx + dy * dy);
        if (len > max) { dx *= max / len; dy *= max / len; ex = ox + dx; ey = oy + dy; }

        Ui.line(ctx, ox, oy, ex, ey, 2, t.accent);

        // znacznik i podpis przy celu
        float mx = MathHelper.clamp(ex, 6, sw - 6), my = MathHelper.clamp(ey, 6, sh - 6);
        Ui.rrect(ctx, Math.round(mx) - 4, Math.round(my) - 4, 8, 8, 4, t.accent);

        TextRenderer tr = mc.textRenderer;
        String label = AttackManager.targetName() + "  " + Math.round(mc.player.distanceTo(target)) + "m  "
                + AttackManager.activeLeftSec() + "s" + (behind ? "  (za Tobą)" : "");
        int w = tr.getWidth(label) + 12;
        int lx = (int) MathHelper.clamp(mx - w / 2f, 4, sw - w - 4);
        int ly = (int) MathHelper.clamp(my - 20, 4, sh - 20);
        Ui.rrect(ctx, lx, ly, w, 14, 4, 0xC0101216);
        ctx.drawText(tr, label, lx + 6, ly + 3, t.accent, false);
    }
}
