package pl.dripeuszek.bomba;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.text.Text;
import net.minecraft.util.math.MathHelper;

import java.util.function.BooleanSupplier;
import java.util.function.Consumer;

/** Małe narzędzia do nowoczesnego wyglądu: zaokrąglone prostokąty, animowane przyciski, przełączniki. */
public final class Ui {
    private Ui() {}

    // ---------- kolory ----------
    public static int alpha(int argb, float f) {
        int a = (int) (((argb >>> 24) & 0xFF) * MathHelper.clamp(f, 0f, 1f));
        return (a << 24) | (argb & 0xFFFFFF);
    }

    public static int withAlpha(int rgb, int a) {
        return (a << 24) | (rgb & 0xFFFFFF);
    }

    public static int lerp(int c1, int c2, float t) {
        t = MathHelper.clamp(t, 0f, 1f);
        int a = ch(c1, c2, 24, t), r = ch(c1, c2, 16, t), g = ch(c1, c2, 8, t), b = ch(c1, c2, 0, t);
        return (a << 24) | (r << 16) | (g << 8) | b;
    }

    private static int ch(int c1, int c2, int shift, float t) {
        int a = (c1 >>> shift) & 0xFF, b = (c2 >>> shift) & 0xFF;
        return a + Math.round((b - a) * t);
    }

    public static int lighten(int c, float amt) {
        return lerp(c, 0xFFFFFFFF, amt);
    }

    // ---------- kształty ----------
    public static void rrect(DrawContext c, int x, int y, int w, int h, int r, int color) {
        if (w <= 0 || h <= 0) return;
        r = Math.max(0, Math.min(r, Math.min(w, h) / 2));
        c.fill(x, y + r, x + w, y + h - r, color);
        for (int i = 0; i < r; i++) {
            double dy = r - i - 0.5;
            int inset = (int) Math.round(r - Math.sqrt(r * r - dy * dy));
            c.fill(x + inset, y + i, x + w - inset, y + i + 1, color);
            c.fill(x + inset, y + h - 1 - i, x + w - inset, y + h - i, color);
        }
    }

    public static int pill(DrawContext c, TextRenderer tr, int x, int y, String label, int color) {
        int w = tr.getWidth(label) + 10;
        rrect(c, x, y, w, 11, 3, withAlpha(color, 0x38));
        c.drawText(tr, label, x + 5, y + 2, color, false);
        return w;
    }

    public static void scaled(DrawContext c, TextRenderer tr, String s, float x, float y, float scale, int color, boolean shadow) {
        MatrixStack m = c.getMatrices();
        m.push();
        m.translate(x, y, 0f);
        m.scale(scale, scale, 1f);
        c.drawText(tr, s, 0, 0, color, shadow);
        m.pop();
    }

    public static void line(DrawContext c, float x1, float y1, float x2, float y2, int th, int color) {
        MinecraftClient mc = MinecraftClient.getInstance();
        int sw = mc.getWindow().getScaledWidth(), sh = mc.getWindow().getScaledHeight();
        float dx = x2 - x1, dy = y2 - y1;
        int steps = (int) Math.min(Math.ceil(Math.sqrt(dx * dx + dy * dy)), 4000);
        if (steps <= 0) return;
        int half = th / 2;
        for (int i = 0; i <= steps; i++) {
            float t = i / (float) steps;
            int x = Math.round(x1 + dx * t), y = Math.round(y1 + dy * t);
            if (x < -th || y < -th || x > sw || y > sh) continue;
            c.fill(x - half, y - half, x - half + th, y - half + th, color);
        }
    }

    // ---------- przyciski ----------
    public static class FlatButton extends ButtonWidget {
        private final boolean primary;
        private float hover;

        public FlatButton(int x, int y, int w, int h, Text msg, boolean primary, ButtonWidget.PressAction onPress) {
            super(x, y, w, h, msg, onPress, DEFAULT_NARRATION_SUPPLIER);
            this.primary = primary;
        }

        @Override
        public void renderWidget(DrawContext c, int mx, int my, float delta) {
            Theme t = Theme.current();
            hover += (((isHovered() && active) ? 1f : 0f) - hover) * 0.3f;
            int base = primary ? t.accent : t.card;
            int hov = primary ? lighten(t.accent, 0.22f) : t.cardHover;
            int col = lerp(base, hov, hover);
            if (!active) col = lerp(col, t.bg, 0.55f);
            rrect(c, getX(), getY(), getWidth(), getHeight(), 4, col);
            int tc = primary ? t.onAccent : t.text;
            if (!active) tc = lerp(tc, t.bg, 0.45f);
            TextRenderer tr = MinecraftClient.getInstance().textRenderer;
            c.drawText(tr, getMessage(), getX() + (getWidth() - tr.getWidth(getMessage())) / 2,
                    getY() + (getHeight() - 8) / 2, tc, false);
        }
    }

    public static class TabButton extends ButtonWidget {
        private final boolean selected;
        private final String label;
        private float hover;

        public TabButton(int x, int y, int w, int h, String label, boolean selected, ButtonWidget.PressAction onPress) {
            super(x, y, w, h, Text.literal(label), onPress, DEFAULT_NARRATION_SUPPLIER);
            this.label = label;
            this.selected = selected;
        }

        @Override
        public void renderWidget(DrawContext c, int mx, int my, float delta) {
            Theme t = Theme.current();
            hover += ((isHovered() ? 1f : 0f) - hover) * 0.3f;
            int bg = selected ? t.card : lerp(t.sidebar, t.card, hover * 0.7f);
            rrect(c, getX(), getY(), getWidth(), getHeight(), 4, bg);
            if (selected) rrect(c, getX() + 2, getY() + 5, 3, getHeight() - 10, 1, t.accent);
            int tc = selected ? t.text : lerp(t.sub, t.text, hover);
            TextRenderer tr = MinecraftClient.getInstance().textRenderer;
            c.drawText(tr, label, getX() + 12, getY() + (getHeight() - 8) / 2, tc, false);
        }
    }

    public static class ToggleRow extends ButtonWidget {
        private final String label, desc;
        private final BooleanSupplier get;
        private float hover, anim;

        public ToggleRow(int x, int y, int w, int h, String label, String desc, BooleanSupplier get, Consumer<Boolean> set) {
            super(x, y, w, h, Text.literal(label), b -> {
                set.accept(!get.getAsBoolean());
                ModConfig.save();
            }, DEFAULT_NARRATION_SUPPLIER);
            this.label = label;
            this.desc = desc;
            this.get = get;
            this.anim = get.getAsBoolean() ? 1f : 0f;
        }

        @Override
        public void renderWidget(DrawContext c, int mx, int my, float delta) {
            Theme t = Theme.current();
            boolean on = get.getAsBoolean();
            hover += ((isHovered() ? 1f : 0f) - hover) * 0.3f;
            anim += ((on ? 1f : 0f) - anim) * 0.3f;
            int x = getX(), y = getY(), w = getWidth(), h = getHeight();
            rrect(c, x, y, w, h, 6, lerp(t.card, t.cardHover, hover * 0.7f));
            TextRenderer tr = MinecraftClient.getInstance().textRenderer;
            c.drawText(tr, label, x + 10, y + 7, t.text, false);
            c.drawText(tr, desc, x + 10, y + 19, t.sub, false);
            int sw = 30, sh = 14;
            int tx = x + w - sw - 10, ty = y + (h - sh) / 2;
            rrect(c, tx, ty, sw, sh, 7, lerp(lerp(t.cardHover, t.sub, 0.35f), t.accent, anim));
            int kx = tx + 2 + Math.round((sw - 14) * anim);
            rrect(c, kx, ty + 2, 10, 10, 5, 0xFFFFFFFF);
        }
    }

    public static class ThemeCard extends ButtonWidget {
        private final Theme theme;
        private float hover;

        public ThemeCard(int x, int y, int w, int h, Theme theme, ButtonWidget.PressAction onPress) {
            super(x, y, w, h, Text.literal(theme.label), onPress, DEFAULT_NARRATION_SUPPLIER);
            this.theme = theme;
        }

        @Override
        public void renderWidget(DrawContext c, int mx, int my, float delta) {
            Theme cur = Theme.current();
            hover += ((isHovered() ? 1f : 0f) - hover) * 0.3f;
            boolean sel = theme == cur;
            int x = getX(), y = getY(), w = getWidth(), h = getHeight();
            int border = sel ? cur.accent : lerp(cur.cardHover, theme.accent, hover);
            rrect(c, x, y, w, h, 6, border);
            rrect(c, x + 1, y + 1, w - 2, h - 2, 5, theme.bg);
            rrect(c, x + 5, y + 5, 14, h - 10, 3, theme.sidebar);
            rrect(c, x + 24, y + 8, w - 34, 6, 2, theme.accent);
            rrect(c, x + 24, y + 18, (int) ((w - 34) * 0.65f), 5, 2, theme.cardHover);
            TextRenderer tr = MinecraftClient.getInstance().textRenderer;
            c.drawText(tr, theme.label, x + 24, y + h - 16, theme.text, false);
            if (sel) rrect(c, x + w - 14, y + h - 14, 8, 8, 4, theme.accent);
        }
    }
}
