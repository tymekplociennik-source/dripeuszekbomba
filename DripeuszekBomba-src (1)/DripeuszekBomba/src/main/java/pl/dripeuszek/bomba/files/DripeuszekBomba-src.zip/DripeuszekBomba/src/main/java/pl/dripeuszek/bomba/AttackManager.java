package pl.dripeuszek.bomba;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;

import java.util.UUID;

/** ATAK = oznaczenie gracza jako cel na 60 s, potem 60 s cooldownu. */
public final class AttackManager {
    private AttackManager() {}

    public static final long DURATION_MS = 60_000L;
    public static final long COOLDOWN_MS = 60_000L;

    private static UUID targetId;
    private static String targetName = "";
    private static long endAt;
    private static long cooldownUntil = Long.MIN_VALUE;

    private static long now() {
        return System.nanoTime() / 1_000_000L;
    }

    public static boolean isActive() {
        return targetId != null && now() < endAt;
    }

    public static boolean canStart() {
        return !isActive() && now() >= cooldownUntil;
    }

    public static void start(UUID id, String name) {
        long n = now();
        targetId = id;
        targetName = name;
        endAt = n + DURATION_MS;
        cooldownUntil = endAt + COOLDOWN_MS;
    }

    public static long activeLeftSec() {
        return isActive() ? (endAt - now() + 999) / 1000 : 0;
    }

    public static long cooldownLeftSec() {
        long n = now();
        if (targetId == null || isActive() || n >= cooldownUntil) return 0;
        return (cooldownUntil - n + 999) / 1000;
    }

    public static boolean isMarked(UUID id) {
        return isActive() && id != null && id.equals(targetId);
    }

    public static UUID targetId() {
        return targetId;
    }

    public static String targetName() {
        return targetName;
    }

    /** Mała plakietka na środku u góry ekranu. */
    public static void renderHud(DrawContext ctx, MinecraftClient mc) {
        Theme t = Theme.current();
        String s;
        int color;
        if (isActive()) {
            s = "ATAK  " + targetName + "  " + activeLeftSec() + "s";
            color = t.accent;
        } else if (cooldownLeftSec() > 0) {
            s = "ATAK cooldown  " + cooldownLeftSec() + "s";
            color = 0xFFB0B6C2;
        } else {
            return;
        }
        TextRenderer tr = mc.textRenderer;
        int w = tr.getWidth(s) + 18;
        int x = (mc.getWindow().getScaledWidth() - w) / 2;
        int y = 6;
        Ui.rrect(ctx, x, y, w, 16, 5, 0xB0101216);
        Ui.rrect(ctx, x + 4, y + 3, 2, 10, 1, color);
        ctx.drawText(tr, s, x + 10, y + 4, color, false);
    }
}
