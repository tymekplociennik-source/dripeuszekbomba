package pl.dripeuszek.bomba;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class DripeuszekBombaClient implements ClientModInitializer {
    private static KeyBinding openKey;

    @Override
    public void onInitializeClient() {
        ModConfig.load();

        // Klawisz "." (kropka) otwiera menu
        openKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.dripeuszekbomba.open",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_PERIOD,
                "key.categories.dripeuszekbomba"
        ));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (openKey.wasPressed()) {
                if (client.currentScreen == null && client.player != null) {
                    LicenseManager.invalidateCache();
                    // bez licencji -> ekran z kluczem, z licencją -> normalne GUI
                    client.setScreen(LicenseManager.isActivated() ? new BombaScreen() : new LicenseScreen());
                }
            }
        });

        HudRenderCallback.EVENT.register(DripeuszekBombaClient::renderHud);
    }

    private static void renderHud(DrawContext ctx, RenderTickCounter tickCounter) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.world == null || mc.options.hudHidden) return;
        if (!LicenseManager.isActivated()) return; // funkcje działają tylko z aktywną licencją

        ModConfig cfg = ModConfig.get();
        Theme t = Theme.current();
        TextRenderer tr = mc.textRenderer;

        List<String> lines = new ArrayList<>();
        if (cfg.showFps) lines.add("FPS  " + mc.getCurrentFps());
        if (cfg.showCoords) {
            lines.add(String.format(Locale.ROOT, "XYZ  %.1f  %.1f  %.1f",
                    mc.player.getX(), mc.player.getY(), mc.player.getZ()));
        }
        if (!lines.isEmpty()) {
            int w = 0;
            for (String s : lines) w = Math.max(w, tr.getWidth(s));
            w += 16;
            int h = lines.size() * 11 + 6;
            Ui.rrect(ctx, 4, 4, w, h, 5, 0xB0101216);
            Ui.rrect(ctx, 8, 7, 2, h - 6, 1, t.accent);
            int y = 8;
            for (String s : lines) {
                ctx.drawText(tr, s, 14, y, 0xFFFFFFFF, false);
                y += 11;
            }
        }

        if (cfg.tracers) {
            Tracers.render(ctx, mc, tickCounter.getTickDelta(true));
        }
        AttackManager.renderHud(ctx, mc);
    }
}
