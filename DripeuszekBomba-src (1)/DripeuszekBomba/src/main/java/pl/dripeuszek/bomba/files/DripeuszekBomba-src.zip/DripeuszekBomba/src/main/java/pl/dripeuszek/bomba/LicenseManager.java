package pl.dripeuszek.bomba;

import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.MinecraftClient;

import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.security.KeyFactory;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.Signature;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.X509EncodedKeySpec;
import java.time.LocalDateTime;
import java.util.Base64;

/**
 * Licencje oparte na podpisie cyfrowym Ed25519.
 * - W modzie jest tylko KLUCZ PUBLICZNY (sprawdza, czy klucz licencyjny jest prawdziwy).
 * - Klucze licencyjne może tworzyć tylko ten, kto ma plik owner.key (klucz prywatny).
 */
public final class LicenseManager {
    private LicenseManager() {}

    private static final String PUBLIC_KEY_B64 = "MCowBQYDK2VwAyEAwBbH+zhExZgU8pPgQJ7J+iHd94E923s9L2vB/HSJGt4=";

    public static final Path DIR = FabricLoader.getInstance().getConfigDir().resolve("dripeuszekbomba");
    private static final Path OWNER_KEY_FILE = DIR.resolve("owner.key");
    private static final Path ISSUED_LOG = DIR.resolve("wydane-klucze.txt");

    private static final Base64.Encoder ENC = Base64.getUrlEncoder().withoutPadding();
    private static final Base64.Decoder DEC = Base64.getUrlDecoder();

    public enum Rank { OWNER, DEFAULT }

    public record Status(boolean valid, String message, String nick, long expiresAt) {}

    private static PublicKey publicKey;
    private static PrivateKey ownerKey;
    private static boolean ownerValue;
    private static long ownerCheckedAt;

    private static long statusCheckedAt;
    private static Status cachedStatus;

    public static String playerName() {
        try {
            return MinecraftClient.getInstance().getSession().getUsername();
        } catch (Exception e) {
            return "Gracz";
        }
    }

    private static PublicKey publicKey() throws Exception {
        if (publicKey == null) {
            publicKey = KeyFactory.getInstance("Ed25519")
                    .generatePublic(new X509EncodedKeySpec(Base64.getDecoder().decode(PUBLIC_KEY_B64)));
        }
        return publicKey;
    }

    /** Czy na tym komputerze jest poprawny owner.key. */
    public static boolean isOwner() {
        long now = System.currentTimeMillis();
        if (now - ownerCheckedAt < 3000) return ownerValue;
        ownerCheckedAt = now;
        ownerValue = false;
        ownerKey = null;
        try {
            if (Files.exists(OWNER_KEY_FILE)) {
                String b64 = Files.readString(OWNER_KEY_FILE).replaceAll("\\s+", "");
                PrivateKey priv = KeyFactory.getInstance("Ed25519")
                        .generatePrivate(new PKCS8EncodedKeySpec(Base64.getDecoder().decode(b64)));
                // test: podpisz coś kluczem prywatnym i sprawdź kluczem publicznym wbudowanym w moda
                byte[] data = "dripeuszekbomba-owner-check".getBytes(StandardCharsets.UTF_8);
                Signature s = Signature.getInstance("Ed25519");
                s.initSign(priv);
                s.update(data);
                byte[] sig = s.sign();
                Signature v = Signature.getInstance("Ed25519");
                v.initVerify(publicKey());
                v.update(data);
                if (v.verify(sig)) {
                    ownerKey = priv;
                    ownerValue = true;
                }
            }
        } catch (Exception ignored) {
        }
        return ownerValue;
    }

    public static Rank rank() {
        return isOwner() ? Rank.OWNER : Rank.DEFAULT;
    }

    /** Tworzy klucz licencyjny dla danego nicku. durationMs = 0 oznacza bezterminowo. Tylko owner. */
    public static String createKey(String nick, long durationMs) throws Exception {
        if (!isOwner() || ownerKey == null) {
            throw new IllegalStateException("Tylko owner może tworzyć licencje.");
        }
        long now = System.currentTimeMillis();
        long expires = durationMs <= 0 ? 0 : now + durationMs;
        String payload = "D1|" + nick.toLowerCase() + "|" + expires + "|" + now;
        byte[] payloadBytes = payload.getBytes(StandardCharsets.UTF_8);
        Signature s = Signature.getInstance("Ed25519");
        s.initSign(ownerKey);
        s.update(payloadBytes);
        String key = ENC.encodeToString(payloadBytes) + "." + ENC.encodeToString(s.sign());
        try {
            String line = LocalDateTime.now() + " | " + nick + " | "
                    + (expires == 0 ? "bezterminowo" : "do " + java.time.Instant.ofEpochMilli(expires)) + " | " + key + System.lineSeparator();
            Files.writeString(ISSUED_LOG, line, StandardOpenOption.CREATE, StandardOpenOption.APPEND);
        } catch (Exception ignored) {
        }
        return key;
    }

    private static Status bad(String msg) {
        return new Status(false, msg, "", 0);
    }

    public static Status validate(String raw, String playerNick) {
        if (raw == null || raw.isBlank()) return bad("Wklej klucz licencyjny.");
        String key = raw.replaceAll("\\s+", "");
        String[] parts = key.split("\\.");
        if (parts.length != 2) return bad("Niepoprawny format klucza.");
        try {
            byte[] payload = DEC.decode(parts[0]);
            byte[] sig = DEC.decode(parts[1]);
            Signature v = Signature.getInstance("Ed25519");
            v.initVerify(publicKey());
            v.update(payload);
            if (!v.verify(sig)) return bad("Nieprawidłowy klucz licencyjny.");
            String[] f = new String(payload, StandardCharsets.UTF_8).split("\\|");
            if (f.length != 4 || !f[0].equals("D1")) return bad("Nieobsługiwany klucz.");
            String keyNick = f[1];
            long exp = Long.parseLong(f[2]);
            if (!keyNick.equalsIgnoreCase(playerNick)) {
                return new Status(false, "Ten klucz jest przypisany do nicku: " + keyNick, keyNick, exp);
            }
            if (exp != 0 && System.currentTimeMillis() > exp) {
                return new Status(false, "Ta licencja wygasła.", keyNick, exp);
            }
            return new Status(true, "Licencja aktywna.", keyNick, exp);
        } catch (Exception e) {
            return bad("Niepoprawny klucz licencyjny.");
        }
    }

    public static Status currentStatus() {
        long now = System.currentTimeMillis();
        if (cachedStatus == null || now - statusCheckedAt > 1000) {
            statusCheckedAt = now;
            if (isOwner()) {
                cachedStatus = new Status(true, "Owner – licencja nieograniczona.", playerName(), 0);
            } else {
                cachedStatus = validate(ModConfig.get().license, playerName());
            }
        }
        return cachedStatus;
    }

    public static boolean isActivated() {
        return currentStatus().valid();
    }

    public static void invalidateCache() {
        statusCheckedAt = 0;
        ownerCheckedAt = 0;
        cachedStatus = null;
    }
}
