package pl.dripeuszek.bomba;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.PlayerSkinDrawer;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.text.OrderedText;
import net.minecraft.text.Text;
import net.minecraft.util.math.MathHelper;

import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;
import java.util.UUID;

/** Główne GUI (po aktywacji licencji): zakładki po lewej – Gracze, Ustawienia, Motywy, Licencja. */
public class BombaScreen extends BaseScreen {
    private enum Tab {
        GRACZE("Gracze"),
        USTAWIENIA("Ustawienia"),
        MOTYWY("Motywy"),
        LICENCJA("Licencja");

        final String label;
        Tab(String label) { this.label = label; }
    }

    private static final int SIDE = 120;
    private static final int ROW_H = 28;
    private static final String[] DUR_LABELS = {"1 dzień", "7 dni", "30 dni", "90 dni", "365 dni", "Bezterminowo"};
    private static final long DAY = 86_400_000L;
    private static final long[] DUR_MS = {DAY, 7 * DAY, 30 * DAY, 90 * DAY, 365 * DAY, 0L};

    private static Tab currentTab = Tab.GRACZE;
    private static UUID selected;
    private static int durIndex = 2;
    private static String lastNick = "";
    private static String lastKey = "";
    private static String genInfo = "";
    private static boolean genError;

    private double scroll, maxScroll;
    private int px, py, pw, ph, cx, cy, cw, chH;
    private int lx, ly, lw, lh, rx, rw;
    private Ui.FlatButton attackBtn;
    private TextFieldWidget nickField;

    public BombaScreen() {
        super(Text.literal("DripeuszekBomba"));
    }

    // ------------------------------------------------------------------ init

    @Override
    protected void init() {
        pw = Math.min(width - 16, 500);
        ph = Math.min(height - 16, 310);
        px = (width - pw) / 2;
        py = (height - ph) / 2;
        cx = px + SIDE + 14;
        cy = py + 50;
        cw = pw - SIDE - 28;
        chH = ph - 50 - 12;
        attackBtn = null;
        nickField = null;

        int ty = py + 62;
        for (Tab tab : Tab.values()) {
            addDrawableChild(new Ui.TabButton(px + 8, ty, SIDE - 16, 22, tab.label, tab == currentTab, b -> {
                currentTab = tab;
                scroll = 0;
                clearAndInit();
            }));
            ty += 26;
        }

        switch (currentTab) {
            case GRACZE -> initPlayers();
            case USTAWIENIA -> initSettings();
            case MOTYWY -> initThemes();
            case LICENCJA -> initLicense();
        }
    }

    private void initPlayers() {
        lx = cx;
        ly = cy;
        lw = (int) (cw * 0.5);
        lh = chH;
        rx = cx + lw + 8;
        rw = cw - lw - 8;
        if (selected != null) {
            attackBtn = addDrawableChild(new Ui.FlatButton(rx + 10, ly + lh - 34, rw - 20, 24,
                    Text.literal("ATAK"), true, b -> startAttack()));
            updateAttackBtn();
        }
    }

    private void initSettings() {
        ModConfig cfg = ModConfig.get();
        addDrawableChild(new Ui.ToggleRow(cx, cy, cw, 34, "Tracery na cel ATAK",
                "Linia od dołu ekranu do oznaczonego gracza", () -> cfg.tracers, v -> cfg.tracers = v));
        addDrawableChild(new Ui.ToggleRow(cx, cy + 40, cw, 34, "Pokaż FPS",
                "Licznik FPS w rogu ekranu", () -> cfg.showFps, v -> cfg.showFps = v));
        addDrawableChild(new Ui.ToggleRow(cx, cy + 80, cw, 34, "Pokaż koordynaty",
                "Pozycja XYZ w rogu ekranu", () -> cfg.showCoords, v -> cfg.showCoords = v));
    }

    private void initThemes() {
        int cols = 3, gap = 8;
        int cardW = (cw - gap * (cols - 1)) / cols;
        int cardH = 60;
        int i = 0;
        for (Theme th : Theme.values()) {
            int x = cx + (i % cols) * (cardW + gap);
            int y = cy + (i / cols) * (cardH + gap);
            addDrawableChild(new Ui.ThemeCard(x, y, cardW, cardH, th, b -> {
                ModConfig.get().theme = th.name();
                ModConfig.save();
            }));
            i++;
        }
    }

    private void initLicense() {
        if (LicenseManager.isOwner()) {
            int gy = cy + 78;
            nickField = new TextFieldWidget(textRenderer, cx + 18, gy + 39, cw - 36, 12, Text.literal("Nick"));
            nickField.setDrawsBackground(false);
            nickField.setMaxLength(16);
            nickField.setText(lastNick);
            nickField.setChangedListener(s -> lastNick = s);
            nickField.setPlaceholder(Text.literal("np. Steve"));
            addDrawableChild(nickField);

            int half = (cw - 26) / 2;
            addDrawableChild(new Ui.FlatButton(cx + 10, gy + 64, half, 22,
                    Text.literal("Czas: " + DUR_LABELS[durIndex]), false, b -> {
                durIndex = (durIndex + 1) % DUR_LABELS.length;
                b.setMessage(Text.literal("Czas: " + DUR_LABELS[durIndex]));
            }));
            addDrawableChild(new Ui.FlatButton(cx + 16 + half, gy + 64, half, 22,
                    Text.literal("Generuj klucz"), true, b -> generate()));
        } else {
            addDrawableChild(new Ui.FlatButton(cx, cy + 78, 130, 22, Text.literal("Zmień klucz"), false,
                    b -> client.setScreen(new LicenseScreen())));
        }
    }

    // ------------------------------------------------------------------ logika

    private List<PlayerListEntry> players() {
        if (client == null || client.getNetworkHandler() == null) return List.of();
        List<PlayerListEntry> l = new ArrayList<>(client.getNetworkHandler().getPlayerList());
        l.sort(Comparator.comparing(e -> e.getProfile().getName().toLowerCase(Locale.ROOT)));
        return l;
    }

    private PlayerListEntry find(UUID id) {
        if (id == null) return null;
        for (PlayerListEntry e : players()) {
            if (e.getProfile().getId().equals(id)) return e;
        }
        return null;
    }

    private boolean isSelf(UUID id) {
        return client != null && client.player != null && client.player.getUuid().equals(id);
    }

    private void startAttack() {
        PlayerListEntry e = find(selected);
        if (e == null || isSelf(selected) || !AttackManager.canStart()) return;
        String name = e.getProfile().getName();
        AttackManager.start(selected, name);
        client.inGameHud.getChatHud().addMessage(Text.literal(
                "§b[DripeuszekBomba] §fATAK na §e" + name + "§f – 60 s"));
        updateAttackBtn();
    }

    private void updateAttackBtn() {
        if (attackBtn == null) return;
        if (isSelf(selected)) {
            attackBtn.setMessage(Text.literal("To Ty"));
            attackBtn.active = false;
        } else if (AttackManager.isActive()) {
            boolean same = AttackManager.isMarked(selected);
            attackBtn.setMessage(Text.literal((same ? "AKTYWNY  " : "Trwa atak  ") + AttackManager.activeLeftSec() + "s"));
            attackBtn.active = false;
        } else if (AttackManager.cooldownLeftSec() > 0) {
            attackBtn.setMessage(Text.literal("Cooldown  " + AttackManager.cooldownLeftSec() + "s"));
            attackBtn.active = false;
        } else {
            attackBtn.setMessage(Text.literal("ATAK"));
            attackBtn.active = true;
        }
    }

    private void generate() {
        String nick = nickField == null ? "" : nickField.getText().trim();
        if (!nick.matches("[A-Za-z0-9_]{3,16}")) {
            genInfo = "Podaj poprawny nick (3-16 znaków: litery, cyfry, _).";
            genError = true;
            return;
        }
        try {
            String key = LicenseManager.createKey(nick, DUR_MS[durIndex]);
            lastKey = key;
            genError = false;
            client.keyboard.setClipboard(key);
            genInfo = "Klucz dla " + nick + " (" + DUR_LABELS[durIndex] + ") skopiowany do schowka.";
        } catch (Exception e) {
            lastKey = "";
            genError = true;
            genInfo = "Błąd: " + e.getMessage();
        }
    }

    @Override
    public void tick() {
        super.tick();
        updateAttackBtn();
    }

    // ------------------------------------------------------------------ input

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (super.mouseClicked(mouseX, mouseY, button)) return true;
        if (currentTab == Tab.GRACZE && button == 0
                && mouseX >= lx && mouseX < lx + lw - 10 && mouseY >= ly && mouseY < ly + lh) {
            int idx = (int) ((mouseY - ly - 4 + scroll) / ROW_H);
            List<PlayerListEntry> list = players();
            if (idx >= 0 && idx < list.size()) {
                selected = list.get(idx).getProfile().getId();
                clearAndInit();
                return true;
            }
        }
        return false;
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        if (currentTab == Tab.GRACZE) {
            scroll = MathHelper.clamp(scroll - verticalAmount * 14, 0, maxScroll);
            return true;
        }
        return super.mouseScrolled(mouseX, mouseY, horizontalAmount, verticalAmount);
    }

    // ------------------------------------------------------------------ render

    @Override
    public void render(DrawContext c, int mx, int my, float delta) {
        Theme t = Theme.current();
        float a = anim();

        c.fill(0, 0, width, height, Ui.alpha(0xAA000000, a));
        Ui.rrect(c, px + 3, py + 4, pw, ph, 9, Ui.alpha(0x70000000, a));
        Ui.rrect(c, px, py, pw, ph, 8, Ui.alpha(t.bg, a));
        Ui.rrect(c, px, py, SIDE, ph, 8, Ui.alpha(t.sidebar, a));
        c.fill(px + SIDE - 8, py, px + SIDE, py + ph, Ui.alpha(t.sidebar, a));
        c.fill(px + 6, py, px + pw - 6, py + 2, Ui.alpha(t.accent, a));

        // logo
        Ui.scaled(c, textRenderer, "DRIPEUSZEK", px + 14, py + 12, 1.25f, Ui.alpha(t.text, a), false);
        Ui.scaled(c, textRenderer, "BOMBA", px + 14, py + 25, 1.25f, Ui.alpha(t.accent, a), false);
        c.fill(px + 14, py + 46, px + SIDE - 14, py + 47, t.cardHover);

        // stopka z nickiem i rangą
        LicenseManager.Rank rank = LicenseManager.rank();
        String nick = textRenderer.trimToWidth(LicenseManager.playerName(), SIDE - 28);
        c.drawText(textRenderer, nick, px + 14, py + ph - 40, t.text, false);
        Ui.pill(c, textRenderer, px + 14, py + ph - 26,
                rank == LicenseManager.Rank.OWNER ? "OWNER" : "DEFAULT",
                rank == LicenseManager.Rank.OWNER ? 0xFFFFB020 : t.sub);

        // nagłówek zakładki
        Ui.scaled(c, textRenderer, currentTab.label, cx, py + 14, 1.5f, t.text, false);
        Ui.rrect(c, cx, py + 35, 22, 2, 1, t.accent);

        switch (currentTab) {
            case GRACZE -> renderPlayers(c, t, mx, my);
            case USTAWIENIA -> c.drawText(textRenderer, "Zmiany zapisują się automatycznie.", cx, cy + 124, t.sub, false);
            case MOTYWY -> c.drawText(textRenderer, "Wybierz kolor interfejsu.", cx, cy + 2 * 68 + 4, t.sub, false);
            case LICENCJA -> renderLicense(c, t);
        }

        super.render(c, mx, my, delta);
    }

    private int wrapped(DrawContext c, String s, int x, int y, int w, int color) {
        List<OrderedText> lines = textRenderer.wrapLines(Text.literal(s), w);
        for (OrderedText l : lines) {
            c.drawText(textRenderer, l, x, y, color, false);
            y += 10;
        }
        return lines.size() * 10;
    }

    private void renderPlayers(DrawContext c, Theme t, int mx, int my) {
        List<PlayerListEntry> list = players();

        // lista
        Ui.rrect(c, lx, ly, lw, lh, 6, t.card);
        maxScroll = Math.max(0, list.size() * ROW_H + 8 - lh);
        scroll = MathHelper.clamp(scroll, 0, maxScroll);

        c.enableScissor(lx, ly, lx + lw, ly + lh);
        int i = 0;
        for (PlayerListEntry e : list) {
            int y0 = ly + 4 - (int) scroll + i * ROW_H;
            i++;
            if (y0 + 24 < ly || y0 > ly + lh) continue;
            UUID id = e.getProfile().getId();
            boolean hov = mx >= lx + 4 && mx < lx + lw - 10 && my >= y0 && my < y0 + 24 && my >= ly && my < ly + lh;
            boolean sel = id.equals(selected);
            int bg = sel ? t.cardHover : (hov ? Ui.lerp(t.card, t.cardHover, 0.5f) : t.bg);
            Ui.rrect(c, lx + 4, y0, lw - 14, 24, 4, bg);
            if (sel) Ui.rrect(c, lx + 4, y0 + 4, 2, 16, 1, t.accent);
            PlayerSkinDrawer.draw(c, e.getSkinTextures(), lx + 10, y0 + 4, 16);

            int pillW = AttackManager.isMarked(id) ? 40 : 0;
            String name = textRenderer.trimToWidth(e.getProfile().getName(), lw - 14 - 32 - pillW - 6);
            c.drawText(textRenderer, name, lx + 32, y0 + 3, t.text, false);
            c.drawText(textRenderer, e.getLatency() + " ms" + (isSelf(id) ? "  •  Ty" : ""), lx + 32, y0 + 13, t.sub, false);
            if (pillW > 0) Ui.pill(c, textRenderer, lx + lw - 14 - pillW + 2, y0 + 6, "ATAK", t.accent);
        }
        c.disableScissor();

        if (list.isEmpty()) {
            c.drawText(textRenderer, "Brak graczy online.", lx + 10, ly + 10, t.sub, false);
        }
        if (maxScroll > 0) {
            int trackH = lh - 8;
            int thumbH = Math.max(16, (int) (trackH * (lh / (double) (list.size() * ROW_H + 8))));
            int thumbY = ly + 4 + (int) ((trackH - thumbH) * (scroll / maxScroll));
            Ui.rrect(c, lx + lw - 6, thumbY, 3, thumbH, 1, t.cardHover);
        }

        // panel ATAK
        Ui.rrect(c, rx, ly, rw, lh, 6, t.card);
        PlayerListEntry sel = find(selected);
        if (sel == null) {
            wrapped(c, "Kliknij gracza na liście, aby otworzyć panel ATAK.", rx + 12, ly + 14, rw - 24, t.sub);
            return;
        }
        PlayerSkinDrawer.draw(c, sel.getSkinTextures(), rx + 12, ly + 12, 32);
        Ui.scaled(c, textRenderer, textRenderer.trimToWidth(sel.getProfile().getName(), (int) ((rw - 64) / 1.2f)),
                rx + 54, ly + 14, 1.2f, t.text, false);
        c.drawText(textRenderer, sel.getLatency() + " ms", rx + 54, ly + 29, t.sub, false);

        c.drawText(textRenderer, "PANEL ATAK", rx + 12, ly + 56, t.accent, false);
        int used = wrapped(c, "Oznacza gracza jako cel na 60 s (tracer), potem 60 s cooldownu.",
                rx + 12, ly + 70, rw - 24, t.sub);
        int ny = ly + 70 + used + 6;
        if (!ModConfig.get().tracers) {
            ny += wrapped(c, "Tracery są wyłączone – włącz je w Ustawieniach.", rx + 12, ny, rw - 24, 0xFFFFB020) + 4;
        }
        if (client != null && client.world != null && !isSelf(selected)) {
            PlayerEntity pe = client.world.getPlayerByUuid(selected);
            if (pe == null) {
                wrapped(c, "Gracz jest poza zasięgiem – tracer pojawi się, gdy będzie w pobliżu.", rx + 12, ny, rw - 24, t.sub);
            }
        }
    }

    private static String expiryText(LicenseManager.Status st) {
        if (st.expiresAt() == 0) return "Ważna: bezterminowo";
        LocalDateTime dt = LocalDateTime.ofInstant(Instant.ofEpochMilli(st.expiresAt()), ZoneId.systemDefault());
        long days = Math.max(0, (st.expiresAt() - System.currentTimeMillis()) / DAY);
        return "Ważna do: " + dt.format(DateTimeFormatter.ofPattern("dd.MM.yyyy HH:mm")) + " (" + days + " dni)";
    }

    private void renderLicense(DrawContext c, Theme t) {
        // karta profilu
        Ui.rrect(c, cx, cy, cw, 70, 6, t.card);
        PlayerListEntry me = (client != null && client.player != null) ? find(client.player.getUuid()) : null;
        if (me != null) {
            PlayerSkinDrawer.draw(c, me.getSkinTextures(), cx + 10, cy + 10, 50);
        } else {
            Ui.rrect(c, cx + 10, cy + 10, 50, 50, 4, t.cardHover);
        }
        int tx = cx + 72;
        Ui.scaled(c, textRenderer, LicenseManager.playerName(), tx, cy + 10, 1.4f, t.text, false);
        LicenseManager.Rank rank = LicenseManager.rank();
        Ui.pill(c, textRenderer, tx, cy + 30, rank == LicenseManager.Rank.OWNER ? "OWNER" : "DEFAULT",
                rank == LicenseManager.Rank.OWNER ? 0xFFFFB020 : t.sub);
        LicenseManager.Status st = LicenseManager.currentStatus();
        c.drawText(textRenderer, "Status: " + (st.valid() ? "aktywna" : "nieaktywna"), tx, cy + 46,
                st.valid() ? 0xFF55E08A : 0xFFFF5C5C, false);
        c.drawText(textRenderer, expiryText(st), tx, cy + 57, t.sub, false);

        if (!LicenseManager.isOwner()) return;

        // generator kluczy (tylko owner)
        int gy = cy + 78, gh = chH - 78;
        Ui.rrect(c, cx, gy, cw, gh, 6, t.card);
        c.drawText(textRenderer, "Generator kluczy licencyjnych", cx + 10, gy + 8, t.accent, false);
        c.drawText(textRenderer, "Nick gracza", cx + 10, gy + 21, t.sub, false);
        boolean focus = nickField != null && nickField.isFocused();
        Ui.rrect(c, cx + 10, gy + 32, cw - 20, 22, 4, focus ? t.accent : t.cardHover);
        Ui.rrect(c, cx + 11, gy + 33, cw - 22, 20, 3, t.bg);

        if (!genInfo.isEmpty()) {
            c.drawText(textRenderer, genInfo, cx + 10, gy + 94, genError ? 0xFFFF5C5C : 0xFF55E08A, false);
        }
        if (!lastKey.isEmpty()) {
            List<OrderedText> lines = textRenderer.wrapLines(Text.literal(lastKey), cw - 20);
            int y = gy + 108;
            for (int i = 0; i < lines.size() && i < 5; i++) {
                c.drawText(textRenderer, lines.get(i), cx + 10, y, t.sub, false);
                y += 10;
            }
        }
    }
}
