package pl.dripeuszek.bomba;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;
import net.minecraft.util.math.MathHelper;

/** Wspólna baza ekranów: własne tło, animacja wejścia, gra nie jest pauzowana. */
public abstract class BaseScreen extends Screen {
    private final long opened = System.currentTimeMillis();

    protected BaseScreen(Text title) {
        super(title);
    }

    /** 0..1 z łagodnym wyhamowaniem (animacja pojawiania się). */
    protected float anim() {
        float t = MathHelper.clamp((System.currentTimeMillis() - opened) / 180f, 0f, 1f);
        return 1f - (1f - t) * (1f - t) * (1f - t);
    }

    @Override
    public void renderBackground(DrawContext context, int mouseX, int mouseY, float delta) {
        // tło rysujemy sami w render()
    }

    @Override
    public boolean shouldPause() {
        return false;
    }
}
