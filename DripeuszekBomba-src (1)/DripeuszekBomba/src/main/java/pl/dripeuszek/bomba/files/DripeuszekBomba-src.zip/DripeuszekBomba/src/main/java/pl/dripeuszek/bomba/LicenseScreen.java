package pl.dripeuszek.bomba;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.text.Text;

/** Pierwsze GUI: trzeba wkleić klucz licencyjny, żeby odblokować normalne menu. */
public class LicenseScreen extends BaseScreen {
    private static String draft = "";

    private TextFieldWidget field;
    private String message = "";
    private boolean error;
    private int cx, cy, cw, ch, fx, fw, boxY;

    public LicenseScreen() {
        super(Text.literal("DripeuszekBomba – licencja"));
    }

    @Override
    protected void init() {
        cw = Math.min(width - 16, 340);
        ch = 190;
        cx = (width - cw) / 2;
        cy = (height - ch) / 2;
        fx = cx + 20;
        fw = cw - 40;
        boxY = cy + 88;

        field = new TextFieldWidget(textRenderer, fx + 8, boxY + 7, fw - 16, 12, Text.literal("Klucz"));
        field.setDrawsBackground(false);
        field.setMaxLength(2048);
        field.setText(draft);
        field.setChangedListener(s -> {
            draft = s;
            message = "";
        });
        field.setPlaceholder(Text.literal("Wklej klucz licencyjny..."));
        addDrawableChild(field);
        setInitialFocus(field);

        int half = (fw - 6) / 2;
        addDrawableChild(new Ui.FlatButton(fx, cy + 118, half, 22, Text.literal("Wklej ze schowka"), false, b -> {
            String clip = client.keyboard.getClipboard();
            field.setText(clip == null ? "" : clip.trim());
        }));
        addDrawableChild(new Ui.FlatButton(fx + half + 6, cy + 118, half, 22, Text.literal("Aktywuj"), true, b -> activate()));
    }

    private void activate() {
        String nick = LicenseManager.playerName();
        String key = field.getText().replaceAll("\\s+", "");
        LicenseManager.Status st = LicenseManager.validate(key, nick);
        if (st.valid()) {
            ModConfig.get().license = key;
            ModConfig.save();
            LicenseManager.invalidateCache();
            draft = "";
            client.setScreen(new BombaScreen());
        } else {
            message = st.message();
            error = true;
        }
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (keyCode == 257 || keyCode == 335) { // Enter / Enter (numpad)
            activate();
            return true;
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    @Override
    public void render(DrawContext c, int mouseX, int mouseY, float delta) {
        Theme t = Theme.current();
        float a = anim();

        c.fill(0, 0, width, height, Ui.alpha(0xAA000000, a));
        Ui.rrect(c, cx + 3, cy + 4, cw, ch, 9, Ui.alpha(0x70000000, a));
        Ui.rrect(c, cx, cy, cw, ch, 8, Ui.alpha(t.bg, a));
        c.fill(cx + 6, cy, cx + cw - 6, cy + 2, Ui.alpha(t.accent, a));

        String title = "DripeuszekBomba";
        float scale = 1.6f;
        Ui.scaled(c, textRenderer, title, cx + (cw - textRenderer.getWidth(title) * scale) / 2f, cy + 16, scale, Ui.alpha(t.accent, a), false);
        String sub = "Wklej klucz licencyjny, aby odblokować menu";
        c.drawText(textRenderer, sub, cx + (cw - textRenderer.getWidth(sub)) / 2, cy + 40, t.sub, false);
        String nick = "Twój nick: " + LicenseManager.playerName();
        c.drawText(textRenderer, nick, cx + (cw - textRenderer.getWidth(nick)) / 2, cy + 54, t.text, false);

        c.drawText(textRenderer, "Klucz licencyjny", fx, boxY - 11, t.sub, false);
        Ui.rrect(c, fx, boxY, fw, 22, 4, field.isFocused() ? t.accent : t.cardHover);
        Ui.rrect(c, fx + 1, boxY + 1, fw - 2, 20, 3, t.card);

        if (!message.isEmpty()) {
            int color = error ? 0xFFFF5C5C : 0xFF55E08A;
            c.drawText(textRenderer, message, cx + (cw - textRenderer.getWidth(message)) / 2, cy + 148, color, false);
        }
        String foot = "Klucz dostaniesz od właściciela moda";
        c.drawText(textRenderer, foot, cx + (cw - textRenderer.getWidth(foot)) / 2, cy + ch - 18, t.sub, false);

        super.render(c, mouseX, mouseY, delta);
    }
}
